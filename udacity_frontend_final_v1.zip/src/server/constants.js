
module.exports = {
    GEONAMES_API_URL: 'http://api.geonames.org/searchJSON?maxRows=10&username=nyubblue',
    WEATHER_BIT_API_BASE_URL: 'http://api.weatherbit.io/v2.0/forecast/daily',
    PIXABAY_BASE_URL: 'https://pixabay.com/api',
    API_BASE_URL: 'http://localhost:8081'
}


